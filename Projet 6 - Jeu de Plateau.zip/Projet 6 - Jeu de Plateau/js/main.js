//Contient toutes les instructions du jeu (tour du joueur, etc);
